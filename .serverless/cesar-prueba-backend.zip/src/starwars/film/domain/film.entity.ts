export interface FilmEntity {
  
}