export const tranlationGetPeopleMap = {
    name: "nombre",
    height: "altura",
    mass: "peso",
    hair_color: "color_cabello",
    skin_color: "color_piel",
    eye_color: "color_ojos",
    birth_year: "fecha_nacimiento",
    gender: "genero",
    homeworld: "planeta",
    films: "peliculas",
    species: "especies",
    vehicles: "vehiculos",
    starships: "naves",
    created: "fecha_creacion",
    edited: "fecha_edicion",
    url: "url"
}