import { PeopleEntity } from "../../domain/entities/people.entity"

export interface ResponseAxiosPeopliApi {
    results: PeopleEntity[]
  }